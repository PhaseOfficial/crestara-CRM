const o="/crestara_logo.png";export{o as _};
